package clientejavafx.observador;

/**
 *
 * @author juanl
 */
public interface NotificadoOperacion {
    
    public void notificarOperacion(String tipo, String nombre);
}
