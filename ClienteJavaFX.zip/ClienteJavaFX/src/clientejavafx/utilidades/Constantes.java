package clientejavafx.utilidades;

/**
 *
 * @author juanl
 */
public class Constantes {
    public static final Integer ERROR_URL = 1001;
    public static final Integer ERROR_PETICION = 1002;
    public static final String URL = "http://localhost:8084/API/api/";
}
